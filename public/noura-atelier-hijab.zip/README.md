# Noura Atelier — Katalog Hijab & Admin Dashboard

Arsip ini berisi dua bagian utama:

1. `dist-html-build/`
   Hasil build statis siap deploy (HTML, CSS, JS, dan aset foto hijab).
   Cocok untuk langsung diunggah ke Netlify, Vercel, GitHub Pages, atau web server statis.

2. `source-code/`
   Seluruh kode sumber lengkap (React, TypeScript, Tailwind CSS, Vite, beserta aset gambar di `src/assets/images/`).
   Untuk menjalankan secara lokal:
   - `npm install`
   - `npm run dev` (development di port 3000)
   - `npm run build` (build produksi ke folder `dist/`)

Akun Demo Admin (`/admin/login`):
- Username: admin
- Password: admin
